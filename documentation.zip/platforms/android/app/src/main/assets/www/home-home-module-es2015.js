(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html":
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header [translucent]=\"true\">\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button ></ion-menu-button>\r\n      </ion-buttons>\r\n        <ion-title class=\"ion-text-center\">Weather Check</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content [fullscreen]=\"true\" color= \"Primary\">\r\n  <ion-grid class=\"ion-no-padding\">\r\n    <ion-row>\r\n      <ion-col>\r\n        <ion-card class=\"ion-no-margin content-bg\">\r\n          <ion-card-header>\r\n             <ion-searchbar placeholder=\"Search Location\" ></ion-searchbar>\r\n             <ion-card-title class=\"ion-margin-start\">Weather for {{value}}</ion-card-title>\r\n          </ion-card-header>\r\n          <ion-card-content>\r\n            <ion-grid>\r\n              <ion-row>\r\n                <ion-col size=\"6\">\r\n                    <ion-text class=\"temp-text ion-margin-start\">{{mCurrentTemp}}°C</ion-text>\r\n                    <br>\r\n                    <ion-text class=\"ion-margin-start temp-label\">\r\n                        AND RISING\r\n                    </ion-text>\r\n                    <br>\r\n                    <ion-text class=\"desc-label ion-margin-start \" >\r\n                        {{mWeather}}\r\n                    </ion-text>\r\n                </ion-col>\r\n                <ion-col size=\"6\">\r\n                   <ion-item lines=\"none\" > \r\n                        <ion-thumbnail slot=\"end\">\r\n                          <img src={{mCurrentWeatherIcon}}>                        </ion-thumbnail>\r\n                    </ion-item>\r\n                </ion-col>\r\n              </ion-row>\r\n            </ion-grid>\r\n          </ion-card-content>\r\n        </ion-card>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n  <ion-grid>\r\n    <ion-row>\r\n      <ion-col>\r\n        <ion-card>\r\n          <ion-card-header color=\"primary\">\r\n            <ion-text class=\"card-header\">\r\n                DETAILS\r\n            </ion-text>\r\n          </ion-card-header>\r\n          <ion-card-content>\r\n          <ion-grid>\r\n            <ion-row>\r\n              <ion-col size=\"4\">\r\n                <ion-row>\r\n                  <ion-col>\r\n                    <ion-item lines=\"none\"> \r\n                      <ion-thumbnail slot=\"start\">\r\n                        <img src=\"../../assets/images/precipitation_icon.png\">\r\n                      </ion-thumbnail>\r\n                    </ion-item>\r\n                    <ion-item lines=\"none\">\r\n                        <ion-text >\r\n                            Visibility\r\n                        </ion-text>\r\n                    </ion-item>\r\n                    <ion-item lines=\"none\">\r\n                      <ion-text >\r\n                        16093\r\n                      </ion-text>\r\n                     </ion-item>\r\n                  </ion-col>\r\n                </ion-row>\r\n              </ion-col>\r\n              <ion-col size=\"4\">\r\n                <ion-row>\r\n                  <ion-col>\r\n                    <ion-item lines=\"none\"> \r\n                      <ion-thumbnail slot=\"start\">\r\n                        <img src=\"../../assets/images/wind_icon.png\">\r\n                      </ion-thumbnail>\r\n                    </ion-item>\r\n                    <ion-item lines=\"none\">\r\n                        <ion-text >\r\n                            Wind\r\n                        </ion-text>\r\n                    </ion-item>\r\n                    <ion-item lines=\"none\">\r\n                      <ion-text >\r\n                        {{mWind}}m/s\r\n                      </ion-text>\r\n                     </ion-item>\r\n                  </ion-col>\r\n                </ion-row>\r\n              </ion-col>\r\n              <ion-col size=\"4\">\r\n                <ion-row>\r\n                  <ion-col>\r\n                    <ion-item lines=\"none\"> \r\n                      <ion-thumbnail slot=\"start\">\r\n                        <img src=\"../../assets/images/humidity_icon.png\">\r\n                      </ion-thumbnail>\r\n                    </ion-item>\r\n                    <ion-item lines=\"none\">\r\n                        <ion-text >\r\n                            Humedity\r\n                        </ion-text>\r\n                    </ion-item>\r\n                    <ion-item lines=\"none\">\r\n                      <ion-text >\r\n                        {{mHumidity}}\r\n                      </ion-text>\r\n                     </ion-item>\r\n                  </ion-col>\r\n                </ion-row>\r\n              </ion-col>\r\n            </ion-row>\r\n          </ion-grid>\r\n          </ion-card-content>\r\n        </ion-card>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n  <ion-grid >\r\n    <ion-row>\r\n      <ion-col>\r\n        <ion-card >\r\n          <ion-card-header color=\"primary\">\r\n            <ion-text class=\"card-header\">\r\n                FORECAST\r\n            </ion-text>\r\n          </ion-card-header>\r\n          <ion-card-content>\r\n            <ion-grid>\r\n              <div scrollY=\"true\" id=\"forecastContainer\">\r\n              <ion-row style=\"width: 800px;\" >\r\n                <ion-col *ngFor=\"let day of mDate\" class=\"ion-no-padding\" >\r\n                    <ion-item lines=\"none\" class=\"ion-no-padding\">\r\n                      <ion-text>\r\n                        {{day}}\r\n                      </ion-text> \r\n                    </ion-item>\r\n                    <ion-item lines=\"none\" class=\"ion-no-padding\">\r\n                      <ion-text>\r\n                          15 APR\r\n                      </ion-text> \r\n                    </ion-item>\r\n                </ion-col>\r\n              </ion-row>\r\n            </div>\r\n            </ion-grid>\r\n          </ion-card-content>\r\n        </ion-card>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n <!--- <ion-grid>\r\n    <div scrollY=\"true\" id=\"forecastContainer\">\r\n      <ion-row style=\"width: 1000px;\">\r\n      \r\n       </ion-row>\r\n    </div>\r\n  </ion-grid>-->\r\n  <div id=\"containerchart\">\r\n\r\n    <div id=\"bck\">  <canvas #lineCanvasBckGround></canvas></div>\r\n    <div id=\"min\">  <canvas #lineCanvasMin></canvas></div>\r\n    <div id=\"max\"><canvas #lineCanvasMax></canvas></div>\r\n  \r\n  \r\n    </div>\r\n</ion-content>\r\n");

/***/ }),

/***/ "./src/app/home/home.module.ts":
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/*! exports provided: HomePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageModule", function() { return HomePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./home.page */ "./src/app/home/home.page.ts");







let HomePageModule = class HomePageModule {
};
HomePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                {
                    path: '',
                    component: _home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]
                }
            ])
        ],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]]
    })
], HomePageModule);



/***/ }),

/***/ "./src/app/home/home.page.scss":
/*!*************************************!*\
  !*** ./src/app/home/home.page.scss ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("#container {\n  text-align: center;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 50%;\n  transform: translateY(-50%);\n}\n\n#container strong {\n  font-size: 20px;\n  line-height: 26px;\n}\n\n#container p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n\n#container a {\n  text-decoration: none;\n}\n\nion-content ion-toolbar {\n  --background: translucent;\n}\n\n.temp-text {\n  font-size: 3.3rem;\n}\n\n.temp-label {\n  font-size: 1rem;\n}\n\n.desc-label {\n  font-size: 1.5rem;\n  font-weight: bold;\n  margin-top: 30px;\n}\n\n.card-header {\n  font-size: 1.2rem;\n  font-weight: bold;\n  margin-top: 30px;\n}\n\n.content-bg {\n  background-image: url('Bg_Image_Mobile.png') !important;\n  background-repeat: no-repeat;\n  background-position: center;\n}\n\nion-item {\n  --background:rgba(0, 0, 0, 0);\n}\n\n#forecastContainer {\n  height: 100px;\n}\n\ndiv[scrollx=true] {\n  position: relative;\n  overflow: hidden;\n}\n\ndiv[scrollx=true] {\n  overflow-x: auto;\n}\n\ndiv[scrolly=true] {\n  overflow-y: auto;\n}\n\n::-webkit-scrollbar {\n  display: none;\n}\n\n#containerchart {\n  width: 100%;\n  height: 150px;\n  position: relative;\n  border: #000 solid 1px;\n}\n\n#bck {\n  width: 100%;\n  height: 150px;\n  border: #000 1px solid;\n  position: absolute;\n  z-index: 0;\n  top: 10px;\n}\n\n#max {\n  width: 100%;\n  height: 150px;\n  border: #000 1px solid;\n  position: absolute;\n  z-index: 1;\n  top: 10px;\n}\n\n#min {\n  width: 100%;\n  height: 150px;\n  border: #000 1px solid;\n  position: absolute;\n  z-index: 2;\n  top: 10px;\n}\n\n#top,\n#bottom {\n  float: none;\n  overflow: hidden;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9DOlxcVXNlcnNcXEE2ODc5NjFcXElvbmljXFx3ZWF0aGVyQXBwSW9uaWMvc3JjXFxhcHBcXGhvbWVcXGhvbWUucGFnZS5zY3NzIiwic3JjL2FwcC9ob21lL2hvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usa0JBQUE7RUFFQSxrQkFBQTtFQUNBLE9BQUE7RUFDQSxRQUFBO0VBQ0EsUUFBQTtFQUNBLDJCQUFBO0FDQUY7O0FER0E7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7QUNBRjs7QURHQTtFQUNFLGVBQUE7RUFDQSxpQkFBQTtFQUVBLGNBQUE7RUFFQSxTQUFBO0FDRkY7O0FES0E7RUFDRSxxQkFBQTtBQ0ZGOztBREtBO0VBQ0UseUJBQUE7QUNGRjs7QURJRTtFQUVFLGlCQUFBO0FDRko7O0FES0U7RUFDRixlQUFBO0FDRkE7O0FES0U7RUFDRSxpQkFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7QUNGSjs7QURLRTtFQUNFLGlCQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtBQ0ZKOztBREtFO0VBQ0UsdURBQUE7RUFDQSw0QkFBQTtFQUNBLDJCQUFBO0FDRko7O0FETUU7RUFDRSw2QkFBQTtBQ0hKOztBRE1FO0VBQ0UsYUFBQTtBQ0hKOztBRE1BO0VBQ0Usa0JBQUE7RUFDQSxnQkFBQTtBQ0hGOztBRE1BO0VBQ0UsZ0JBQUE7QUNIRjs7QURNQTtFQUNFLGdCQUFBO0FDSEY7O0FET0E7RUFDRSxhQUFBO0FDSkY7O0FEUUE7RUFDRSxXQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0Esc0JBQUE7QUNMRjs7QURPQTtFQUNFLFdBQUE7RUFDQSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxTQUFBO0FDSkY7O0FETUE7RUFDRSxXQUFBO0VBQ0EsYUFBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0VBQ0EsU0FBQTtBQ0hGOztBREtBO0VBQ0UsV0FBQTtFQUNBLGFBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFNBQUE7QUNGRjs7QURJQTs7RUFFSSxXQUFBO0VBQ0EsZ0JBQUE7QUNESiIsImZpbGUiOiJzcmMvYXBwL2hvbWUvaG9tZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIjY29udGFpbmVyIHtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcblxyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICBsZWZ0OiAwO1xyXG4gIHJpZ2h0OiAwO1xyXG4gIHRvcDogNTAlO1xyXG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtNTAlKTtcclxufVxyXG5cclxuI2NvbnRhaW5lciBzdHJvbmcge1xyXG4gIGZvbnQtc2l6ZTogMjBweDtcclxuICBsaW5lLWhlaWdodDogMjZweDtcclxufVxyXG5cclxuI2NvbnRhaW5lciBwIHtcclxuICBmb250LXNpemU6IDE2cHg7XHJcbiAgbGluZS1oZWlnaHQ6IDIycHg7XHJcblxyXG4gIGNvbG9yOiAjOGM4YzhjO1xyXG5cclxuICBtYXJnaW46IDA7XHJcbn1cclxuXHJcbiNjb250YWluZXIgYSB7XHJcbiAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xyXG59XHJcblxyXG5pb24tY29udGVudCBpb24tdG9vbGJhciB7XHJcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc2x1Y2VudDtcclxufVxyXG4gIC50ZW1wLXRleHR7XHJcblxyXG4gICAgZm9udC1zaXplOjMuM3JlbTtcclxuICB9XHJcblxyXG4gIC50ZW1wLWxhYmVse1xyXG5mb250LXNpemU6MXJlbTtcclxuICB9XHJcblxyXG4gIC5kZXNjLWxhYmVse1xyXG4gICAgZm9udC1zaXplOjEuNXJlbTtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgbWFyZ2luLXRvcDogMzBweDtcclxuICB9XHJcblxyXG4gIC5jYXJkLWhlYWRlcntcclxuICAgIGZvbnQtc2l6ZToxLjJyZW07XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgIG1hcmdpbi10b3A6IDMwcHg7XHJcbiAgfVxyXG5cclxuICAuY29udGVudC1iZyB7XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOnVybCgnLi4vLi4vYXNzZXRzL2ljb24vQmdfSW1hZ2VfTW9iaWxlLnBuZycpICAhaW1wb3J0YW50IDtcclxuICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXI7IFxyXG4gIH1cclxuXHJcblxyXG4gIGlvbi1pdGVte1xyXG4gICAgLS1iYWNrZ3JvdW5kOnJnYmEoMCwgMCwgMCwgMCk7XHJcbiAgfVxyXG5cclxuICAjZm9yZWNhc3RDb250YWluZXJ7XHJcbiAgICBoZWlnaHQ6IDEwMHB4O1xyXG59XHJcblxyXG5kaXZbc2Nyb2xseD10cnVlXSB7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIG92ZXJmbG93OiBoaWRkZW47XHJcbn1cclxuXHJcbmRpdltzY3JvbGx4PXRydWVdIHtcclxuICBvdmVyZmxvdy14OiBhdXRvO1xyXG59XHJcblxyXG5kaXZbc2Nyb2xseT10cnVlXSB7XHJcbiAgb3ZlcmZsb3cteTogYXV0bztcclxufVxyXG5cclxuXHJcbjo6LXdlYmtpdC1zY3JvbGxiYXIge1xyXG4gIGRpc3BsYXk6IG5vbmU7XHJcbn1cclxuXHJcblxyXG4jY29udGFpbmVyY2hhcnQge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMTUwcHg7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlOyAgIFxyXG4gIGJvcmRlcjogIzAwMCBzb2xpZCAxcHg7XHJcbn1cclxuI2JjayB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiAxNTBweDtcclxuICBib3JkZXI6ICMwMDAgMXB4IHNvbGlkO1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB6LWluZGV4OiAwO1xyXG4gIHRvcDogMTBweDtcclxufVxyXG4jbWF4IHtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDE1MHB4O1xyXG4gIGJvcmRlcjogIzAwMCAxcHggc29saWQ7XHJcbiAgcG9zaXRpb246IGFic29sdXRlOyAgXHJcbiAgei1pbmRleDogMTtcclxuICB0b3A6IDEwcHg7XHJcbn1cclxuI21pbiB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiAxNTBweDtcclxuICBib3JkZXI6ICMwMDAgMXB4IHNvbGlkO1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB6LWluZGV4OiAyO1xyXG4gIHRvcDogMTBweDtcclxufVxyXG4jdG9wLFxyXG4jYm90dG9tIHtcclxuICAgIGZsb2F0OiBub25lO1xyXG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcclxufSIsIiNjb250YWluZXIge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbGVmdDogMDtcbiAgcmlnaHQ6IDA7XG4gIHRvcDogNTAlO1xuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTUwJSk7XG59XG5cbiNjb250YWluZXIgc3Ryb25nIHtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBsaW5lLWhlaWdodDogMjZweDtcbn1cblxuI2NvbnRhaW5lciBwIHtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBsaW5lLWhlaWdodDogMjJweDtcbiAgY29sb3I6ICM4YzhjOGM7XG4gIG1hcmdpbjogMDtcbn1cblxuI2NvbnRhaW5lciBhIHtcbiAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xufVxuXG5pb24tY29udGVudCBpb24tdG9vbGJhciB7XG4gIC0tYmFja2dyb3VuZDogdHJhbnNsdWNlbnQ7XG59XG5cbi50ZW1wLXRleHQge1xuICBmb250LXNpemU6IDMuM3JlbTtcbn1cblxuLnRlbXAtbGFiZWwge1xuICBmb250LXNpemU6IDFyZW07XG59XG5cbi5kZXNjLWxhYmVsIHtcbiAgZm9udC1zaXplOiAxLjVyZW07XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBtYXJnaW4tdG9wOiAzMHB4O1xufVxuXG4uY2FyZC1oZWFkZXIge1xuICBmb250LXNpemU6IDEuMnJlbTtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIG1hcmdpbi10b3A6IDMwcHg7XG59XG5cbi5jb250ZW50LWJnIHtcbiAgYmFja2dyb3VuZC1pbWFnZTogdXJsKFwiLi4vLi4vYXNzZXRzL2ljb24vQmdfSW1hZ2VfTW9iaWxlLnBuZ1wiKSAhaW1wb3J0YW50O1xuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXI7XG59XG5cbmlvbi1pdGVtIHtcbiAgLS1iYWNrZ3JvdW5kOnJnYmEoMCwgMCwgMCwgMCk7XG59XG5cbiNmb3JlY2FzdENvbnRhaW5lciB7XG4gIGhlaWdodDogMTAwcHg7XG59XG5cbmRpdltzY3JvbGx4PXRydWVdIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG5kaXZbc2Nyb2xseD10cnVlXSB7XG4gIG92ZXJmbG93LXg6IGF1dG87XG59XG5cbmRpdltzY3JvbGx5PXRydWVdIHtcbiAgb3ZlcmZsb3cteTogYXV0bztcbn1cblxuOjotd2Via2l0LXNjcm9sbGJhciB7XG4gIGRpc3BsYXk6IG5vbmU7XG59XG5cbiNjb250YWluZXJjaGFydCB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDE1MHB4O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGJvcmRlcjogIzAwMCBzb2xpZCAxcHg7XG59XG5cbiNiY2sge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxNTBweDtcbiAgYm9yZGVyOiAjMDAwIDFweCBzb2xpZDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB6LWluZGV4OiAwO1xuICB0b3A6IDEwcHg7XG59XG5cbiNtYXgge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxNTBweDtcbiAgYm9yZGVyOiAjMDAwIDFweCBzb2xpZDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB6LWluZGV4OiAxO1xuICB0b3A6IDEwcHg7XG59XG5cbiNtaW4ge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxNTBweDtcbiAgYm9yZGVyOiAjMDAwIDFweCBzb2xpZDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB6LWluZGV4OiAyO1xuICB0b3A6IDEwcHg7XG59XG5cbiN0b3AsXG4jYm90dG9tIHtcbiAgZmxvYXQ6IG5vbmU7XG4gIG92ZXJmbG93OiBoaWRkZW47XG59Il19 */");

/***/ }),

/***/ "./src/app/home/home.page.ts":
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/*! exports provided: HomePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePage", function() { return HomePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _repository_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../repository.service */ "./src/app/repository.service.ts");
/* harmony import */ var _uiservice_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../uiservice-service.service */ "./src/app/uiservice-service.service.ts");
/* harmony import */ var _uitoast_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../uitoast.service */ "./src/app/uitoast.service.ts");
/* harmony import */ var _temperature_converter_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../temperature-converter.service */ "./src/app/temperature-converter.service.ts");
/* harmony import */ var _over_lap_graph_for_weather_prediction_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../over-lap-graph-for-weather-prediction.service */ "./src/app/over-lap-graph-for-weather-prediction.service.ts");
/* harmony import */ var _buisness_logic_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../buisness-logic.service */ "./src/app/buisness-logic.service.ts");
/* harmony import */ var _get_location_lat_lon_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../get-location-lat-lon.service */ "./src/app/get-location-lat-lon.service.ts");
/* harmony import */ var _get_city_name_geocoder_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../get-city-name-geocoder.service */ "./src/app/get-city-name-geocoder.service.ts");










/**
 * Component for HomePage.ts
 */
let HomePage = 
/**
 * HomePage class
 */
class HomePage {
    /**
     * Constructor for Homepage.ts
     * @param mRepositoryyAPIService Instance of RepositoryyAPIService
     * @param mUIServiceService Instance of UIServiceService
     * @param mUIToastService Instance of UIToastService
     * @param mTemperatureConverterService Instance of TemperatureConverterService
     * @param mOverLapGraphForWeatherPredictionServiceMax Instance of OverLapGraphForWeatherPredictionServiceMa
     * @param mOverLapGraphForWeatherPredictionServiceMin Instance of OverLapGraphForWeatherPredictionServiceMa
     * @param mOverLapGraphForWeatherPredictionServiceBck Instance of OverLapGraphForWeatherPredictionServiceMa
     */
    constructor(mRepositoryyAPIService, mUIServiceService, mUIToastService, mTemperatureConverterService, mOverLapGraphForWeatherPredictionServiceMax, mOverLapGraphForWeatherPredictionServiceMin, mOverLapGraphForWeatherPredictionServiceBck, mBuisnessLogicService, mGetLocationLatLonService, mGetCityNameGeocoderService) {
        this.mRepositoryyAPIService = mRepositoryyAPIService;
        this.mUIServiceService = mUIServiceService;
        this.mUIToastService = mUIToastService;
        this.mTemperatureConverterService = mTemperatureConverterService;
        this.mOverLapGraphForWeatherPredictionServiceMax = mOverLapGraphForWeatherPredictionServiceMax;
        this.mOverLapGraphForWeatherPredictionServiceMin = mOverLapGraphForWeatherPredictionServiceMin;
        this.mOverLapGraphForWeatherPredictionServiceBck = mOverLapGraphForWeatherPredictionServiceBck;
        this.mBuisnessLogicService = mBuisnessLogicService;
        this.mGetLocationLatLonService = mGetLocationLatLonService;
        this.mGetCityNameGeocoderService = mGetCityNameGeocoderService;
        /**
         * Store 5 days Date
         */
        this.mDate = [];
        /**
         * Store 5 days Max Temperature
         */
        this.mDateTempMax = [];
        /**
         * Store 5 days Min Temperature
         */
        this.mDateTempMin = [];
        /**
         * Store Max Temperature in next 5 days
         */
        this.maxTempof5DaysToGrphLimit = 0;
        /**
         * Store Min Temperature in next 5 days
         */
        this.minTempof5DaysToraphLimit = 0;
        /**
         * Value of delta for graph for resizing
         */
        this.mGraphMaxMinFromTempDelta = 7;
        /**
         * Store static value for vwetical scroll
         */
        this.days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
        /**
         * Store five days icon
         */
        this.mFiveDaysWeatherIcon = [];
        //  this.loadFromUrl("Bengaluru");
        this.getLatLon();
    }
    getLatLon() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const valueokok = yield this.mGetLocationLatLonService.getGeolocation();
            if (valueokok !== 'Error')
                this.getCityNameUsingLatLon(Number(valueokok.split("---")[0]), Number(valueokok.split("---")[1]));
            //  this.value=valueokok;
        });
    }
    getCityNameUsingLatLon(lat, lon) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const valueokok = yield this.mGetCityNameGeocoderService.getGeolocation(lat, lon);
            this.loadFromUrl(valueokok);
            this.value = valueokok;
        });
    }
    /**
     * Asynchronous call
     * Load from 'openweathermap' URL
     * @param mCity CityName
     */
    loadFromUrl(mCity) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.mDate = [];
            this.mDateTempMax = [];
            this.mDateTempMin = [];
            this.mUIServiceService.showLoading("Loading...");
            const mFiveDaysValue = yield this.mRepositoryyAPIService.getWeatherValueFiveDays(mCity);
            //console.log(mFiveDaysValue);
            if (JSON.parse(mFiveDaysValue) == "Error") {
                this.mUIServiceService.dismissLoading();
                this.mUIToastService.presentToast();
            }
            else {
                const mCurrentValue = yield this.mRepositoryyAPIService.getWeatherValueCurrent(mCity);
                console.log(mCurrentValue);
                if (JSON.parse(mFiveDaysValue) == "Error") {
                    this.mUIServiceService.dismissLoading();
                    this.mUIToastService.presentToast();
                }
                else {
                    this.mCity = JSON.parse(mCurrentValue).name + " , " + JSON.parse(mCurrentValue).sys.country;
                    this.mCurrentTemp = Math.floor(this.mTemperatureConverterService.kelvinToCelcius((JSON.parse(mCurrentValue).main).temp)).toString();
                    this.mWeather = (JSON.parse(mCurrentValue).weather)[0].description;
                    this.mWind = (JSON.parse(mCurrentValue).wind).speed;
                    this.mHumidity = (JSON.parse(mCurrentValue).main).humidity + "%";
                    this.mCurrentWeatherIcon = this.mBuisnessLogicService.getWeatherIconFromAssetFolder(JSON.parse(mCurrentValue).weather[0].description);
                    ///// Insert Date into this.mDate Array
                    for (let i = 0; i < JSON.parse(mFiveDaysValue).list.length; i++) {
                        console.log(JSON.parse(mFiveDaysValue).list[i]);
                        var mDateAfterAplit = (JSON.parse(mFiveDaysValue).list[i].dt_txt).split(" ")[0];
                        this.mDate.indexOf(mDateAfterAplit) === -1 ? this.mDate.push(mDateAfterAplit) : console.log();
                    }
                    /////// getHigh Log Temp Of Each Day /////
                    for (let i = 0; i < this.mDate.length; i++) {
                        console.log(this.mDate[i]);
                        var mHeigh = 0;
                        var mLow = 0;
                        var mWeatherIcon = "";
                        for (let j = 0; j < JSON.parse(mFiveDaysValue).list.length; j++) {
                            var mDateAfterAplit = (JSON.parse(mFiveDaysValue).list[j].dt_txt).split(" ")[0];
                            if (mDateAfterAplit == this.mDate[i]) {
                                if (mHeigh == 0 && mLow == 0) {
                                    mHeigh = JSON.parse(mFiveDaysValue).list[j].main.temp_max;
                                    mWeatherIcon = this.mBuisnessLogicService.getWeatherIconFromAssetFolder(JSON.parse(mFiveDaysValue).list[j].weather[0].icon);
                                    mLow = JSON.parse(mFiveDaysValue).list[j].main.temp_min;
                                    continue;
                                }
                                else {
                                    if (mHeigh < JSON.parse(mFiveDaysValue).list[j].main.temp_max) {
                                        mHeigh = JSON.parse(mFiveDaysValue).list[j].main.temp_max;
                                        mWeatherIcon = this.mBuisnessLogicService.getWeatherIconFromAssetFolder(JSON.parse(mFiveDaysValue).list[j].weather[0].icon);
                                    }
                                    if (mLow > JSON.parse(mFiveDaysValue).list[j].main.temp_min) {
                                        mLow = JSON.parse(mFiveDaysValue).list[j].main.temp_min;
                                    }
                                }
                            }
                        }
                        this.mDateTempMax.push(Math.floor(this.mTemperatureConverterService.kelvinToCelcius(mHeigh)));
                        this.mDateTempMin.push(Math.floor(this.mTemperatureConverterService.kelvinToCelcius(mLow)));
                        this.mFiveDaysWeatherIcon.push(mWeatherIcon);
                        console.log(this.mTemperatureConverterService.kelvinToCelcius(mHeigh)
                            + "     " + this.mTemperatureConverterService.kelvinToCelcius(mLow));
                    }
                    console.log("Graph Calling");
                    // this.mShowGraphService.showGrapg(this.lineChart,this.lineCanvas,this.mDate,
                    //   this.mDateTempMax,this.mDateTempMin);
                    //   this.mShowGraphService.showGrapg(this.lineChart,this.lineCanvastwo,this.mDate,
                    //     this.mDateTempMax,this.mDateTempMin);
                    this.maxTempof5DaysToGrphLimit = Math.max(...this.mDateTempMax) + this.mGraphMaxMinFromTempDelta;
                    this.minTempof5DaysToraphLimit = Math.min(...this.mDateTempMin) - this.mGraphMaxMinFromTempDelta;
                    this.mOverLapGraphForWeatherPredictionServiceMax.showGrapg(this.lineChartMax, this.lineCanvasMax, this.mDate, this.mDateTempMax, 'Highest', 'rgba(255,255,0)', this.minTempof5DaysToraphLimit, this.maxTempof5DaysToGrphLimit);
                    this.mOverLapGraphForWeatherPredictionServiceMin.showGrapg(this.lineChartMin, this.lineCanvasMin, this.mDate, this.mDateTempMin, 'Lowest', 'rgba(75,192,192)', this.minTempof5DaysToraphLimit, this.maxTempof5DaysToGrphLimit);
                    this.mOverLapGraphForWeatherPredictionServiceBck.showGrapg(this.lineChartBckGround, this.lineCanvasBckGround, this.mDate, [this.maxTempof5DaysToGrphLimit, this.maxTempof5DaysToGrphLimit,
                        this.maxTempof5DaysToGrphLimit, this.maxTempof5DaysToGrphLimit,
                        this.maxTempof5DaysToGrphLimit, this.maxTempof5DaysToGrphLimit], '', 'rgba(75,192,192)', this.minTempof5DaysToraphLimit, this.maxTempof5DaysToGrphLimit);
                    console.log(Math.max(...this.mDateTempMax) + "   " + Math.min(...this.mDateTempMin));
                }
            }
            this.mUIServiceService.dismissLoading();
        });
    }
};
HomePage.ctorParameters = () => [
    { type: _repository_service__WEBPACK_IMPORTED_MODULE_2__["RepositoryService"] },
    { type: _uiservice_service_service__WEBPACK_IMPORTED_MODULE_3__["UIServiceServiceService"] },
    { type: _uitoast_service__WEBPACK_IMPORTED_MODULE_4__["UIToastService"] },
    { type: _temperature_converter_service__WEBPACK_IMPORTED_MODULE_5__["TemperatureConverterService"] },
    { type: _over_lap_graph_for_weather_prediction_service__WEBPACK_IMPORTED_MODULE_6__["OverLapGraphForWeatherPredictionService"] },
    { type: _over_lap_graph_for_weather_prediction_service__WEBPACK_IMPORTED_MODULE_6__["OverLapGraphForWeatherPredictionService"] },
    { type: _over_lap_graph_for_weather_prediction_service__WEBPACK_IMPORTED_MODULE_6__["OverLapGraphForWeatherPredictionService"] },
    { type: _buisness_logic_service__WEBPACK_IMPORTED_MODULE_7__["BuisnessLogicService"] },
    { type: _get_location_lat_lon_service__WEBPACK_IMPORTED_MODULE_8__["GetLocationLatLonService"] },
    { type: _get_city_name_geocoder_service__WEBPACK_IMPORTED_MODULE_9__["GetCityNameGeocoderService"] }
];
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('lineCanvasMax', { static: true }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], HomePage.prototype, "lineCanvasMax", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('lineCanvasMin', { static: true }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], HomePage.prototype, "lineCanvasMin", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('lineCanvasBckGround', { static: true }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], HomePage.prototype, "lineCanvasBckGround", void 0);
HomePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-home',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./home.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./home.page.scss */ "./src/app/home/home.page.scss")).default]
    })
    /**
     * HomePage class
     */
    ,
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_repository_service__WEBPACK_IMPORTED_MODULE_2__["RepositoryService"],
        _uiservice_service_service__WEBPACK_IMPORTED_MODULE_3__["UIServiceServiceService"],
        _uitoast_service__WEBPACK_IMPORTED_MODULE_4__["UIToastService"],
        _temperature_converter_service__WEBPACK_IMPORTED_MODULE_5__["TemperatureConverterService"],
        _over_lap_graph_for_weather_prediction_service__WEBPACK_IMPORTED_MODULE_6__["OverLapGraphForWeatherPredictionService"],
        _over_lap_graph_for_weather_prediction_service__WEBPACK_IMPORTED_MODULE_6__["OverLapGraphForWeatherPredictionService"],
        _over_lap_graph_for_weather_prediction_service__WEBPACK_IMPORTED_MODULE_6__["OverLapGraphForWeatherPredictionService"],
        _buisness_logic_service__WEBPACK_IMPORTED_MODULE_7__["BuisnessLogicService"],
        _get_location_lat_lon_service__WEBPACK_IMPORTED_MODULE_8__["GetLocationLatLonService"],
        _get_city_name_geocoder_service__WEBPACK_IMPORTED_MODULE_9__["GetCityNameGeocoderService"]])
], HomePage);



/***/ })

}]);
//# sourceMappingURL=home-home-module-es2015.js.map